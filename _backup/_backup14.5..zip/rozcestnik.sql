-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Hostiteľ: localhost
-- Čas generovania: Ne 14.Máj 2017, 12:14
-- Verzia serveru: 5.6.26
-- Verzia PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáza: `rozcestnik`
--

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `rozcestnik_cubes`
--

CREATE TABLE IF NOT EXISTS `rozcestnik_cubes` (
  `cube_id` tinyint(4) NOT NULL,
  `url` varchar(50) COLLATE utf8mb4_slovak_ci NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_slovak_ci NOT NULL,
  `title` varchar(30) COLLATE utf8mb4_slovak_ci NOT NULL,
  `color` varchar(20) COLLATE utf8mb4_slovak_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_slovak_ci;

--
-- Sťahujem dáta pre tabuľku `rozcestnik_cubes`
--

INSERT INTO `rozcestnik_cubes` (`cube_id`, `url`, `name`, `title`, `color`) VALUES
(1, 'http://edi.fmph.uniba.sk/~tomcsanyi/sys1.html', 'PP-SP Tomcsanyi', '', ''),
(2, 'http://python.input.sk', 'Python', '', '');

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `rozcestnik_users`
--

CREATE TABLE IF NOT EXISTS `rozcestnik_users` (
  `user_id` int(5) NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_slovak_ci NOT NULL,
  `pass` varchar(32) COLLATE utf8mb4_slovak_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_slovak_ci NOT NULL,
  `surname` varchar(30) COLLATE utf8mb4_slovak_ci NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_slovak_ci;

--
-- Sťahujem dáta pre tabuľku `rozcestnik_users`
--

INSERT INTO `rozcestnik_users` (`user_id`, `email`, `pass`, `name`, `surname`, `admin`) VALUES
(12, 'danko', 'fb97cc6f1ca291c93954883a709b6cc3', 'danko', 'danko', 0);

--
-- Kľúče pre exportované tabuľky
--

--
-- Indexy pre tabuľku `rozcestnik_cubes`
--
ALTER TABLE `rozcestnik_cubes`
  ADD PRIMARY KEY (`cube_id`);

--
-- Indexy pre tabuľku `rozcestnik_users`
--
ALTER TABLE `rozcestnik_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT pre exportované tabuľky
--

--
-- AUTO_INCREMENT pre tabuľku `rozcestnik_cubes`
--
ALTER TABLE `rozcestnik_cubes`
  MODIFY `cube_id` tinyint(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pre tabuľku `rozcestnik_users`
--
ALTER TABLE `rozcestnik_users`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
