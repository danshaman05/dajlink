<?php

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $titulok; ?></title>

<style>
    #tesla {

        /*
        width: auto;
        height: auto;
        max-width: 300px;
        max-height: 300px; */
        float: left; /*
        clear: both; */
    }

    p {
        float: left;
        clear: both;
    }
</style>

</head>
<body>
    <header>
        <h1><?php echo "AHOJ"; ?></h1>
    </header>

    <section>
    <div id='tesla'>
        <img src="https://www.tesla.com/tesla_theme/assets/img/modals/model-select-models.png?20160811" alt="Tesla">
    </div>  

    <p>
    Tesla je drahy automobil z USA, ktory jazdi iba na elektricky pohon. Dojazd Tesla S je cca 460 km. V najnovsej Tesle je aj autopilot.
    </p>  
    

    </section>

</body>
</html>
<?php


?>
