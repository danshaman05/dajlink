stranka bude obsahovat:


ak sa user prihlasi tak napravo sa zobrazi panel, inak sa zobrazia len (default odkazy)
napravo bude panel (vedla section) a tam bude:
	pridanie odkazu 
	pridanie kocky


v databaze:

	kocky aj odkazy
	uzivatelia

ak sa uzivatel prihlasi, zobrazi mu jeho kocky (nacita sa z user_tabulka)
inak: nacita sa defaultne nastavenie (zoznam kociek a odkazov z default_tabulka)

***********
Dolezite terminy:
uzivatel bude moct pridat dolezite terminy a tie sa zobrazia vsetkym.
- moze sa to poriesit tym, ze ak bude zly termin, ludia mozu oznacit ze je to blbost a tym sa zrusi. 
- alebo sa poriesi len tym ze proste autentifikovany uzivatel pridava terminy. (user co ma meno priezvisko)

********
Pristup na pozvanie - prihlasit sa bude moct len niekto so specialnym kodom - kod moze byt na pozvanie (vygenerovany) alebo ja ho urcim a ten poslem ludom. Takto sa dostanu dnu len pozvani ludia. Dalej kazdy uzivatel ma povinne meno - pre identifikaciu - rovnako ako na FB (dolezite aby ak niekto dava nejaku informaciu o skuske napr, aby nezmiatol inych)


*************************
Ake stranky budu:
    o projekte - popis co sa prave deje, atd.. - mohol by tam byt kontaktny formular na "zlepsenie / navrhy" stranky
    na jednej bude administracia - bude to len pre mna stranka - budem moct tam mazat / pridavat clenov / upravovat


Bugy / Whishlist:

	ak vypisem meno do login a meno je zle, nech zostane vypisane
	registraciu dat do tabulky

        ked sa zaregistrujem ako novy clen vpravo nad login pise "meno alebo heslo je nespravne"

        whish: bola by anketa / hlasovalo by sa za najlepsi odkaz na nieco, a to by sa mohlo pridat do hlavnych (default) kociek, alebo by sa zobrazilo ako navrh pre ostatnych
        zlepsit logo

	* opravene // vlozit logo vlavo hore (miesto a href)
