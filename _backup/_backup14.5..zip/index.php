<?php
session_start();

include('db.php');
include('functions.php');

head_func(); // funkcia header (hlavicka) - zobrazi hlavicku + login
include('nav.html');
?>

      <section>
            <div id="div1">
            <?php
                if (isset($_SESSION['email'])) {
                   //echo "user_ID:"  .  "{$_SESSION['user_id']}";
                    print_cubes("user{$_SESSION['user_id']}");
                } else {
                    // echo "nacitavam default cubes";
                   //echo "user_ID:"  .  "{$_SESSION['user_id']}";
                    print_cubes();
                }
            ?>
<!--
                <a href="http://python.input.sk" title="Programovanie 1, 2">Python</a>
                <a id='C-Tat' href="http://dai.fmph.uniba.sk/courses/pphw/">C / Tatrabot</a>
                <a id='PPSP' href="http://edi.fmph.uniba.sk/~tomcsanyi/sys1.html">PP-SP Tomcsanyi</a>
                <a href="http://www.dcs.fmph.uniba.sk/siete/" title="Jaroslav Janáček">PC Siete</a>

                <a href="https://moodle.uniba.sk/moodle/inf11/course/view.php?id=533" title="Hrusecky">Webove aplikacie</a>
                <a href="//moodle.uniba.sk/moodle/inf11/course/view.php?id=528" title="Marek Nagy">Linux pre používateľov</a>
-->
            </div>

            <div id="div2">

                <a href="https://moodle.uniba.sk/moodle/inf11/course/index.php?categoryid=132" style="color: grey; border-color: grey;">Moodle</a>
                <a id="list" href="http://capek.ii.fmph.uniba.sk/list">L.I.S.T</a>

            </div>

            <div id="spodny">
                <a id="projekt" href="http://www.sccg.sk/~lucan/" title="Ročníkový projekt 1">Ročníkový projekt 1</a>
                <a id="sachovnica" href="php/sachovnica.php">PHP sachovnica</a>

                <a id="codebunk" href="https://codebunk.com/b/268127069/">Codebunk</a>
                <a id="repl" href="https://repl.it/" title="Tu mozes kodit v C-cku a Pythone online">Repl.it</a>
                <a id="tutor" href="http://www.pythontutor.com/live.html#mode=edit" title="PythonTutor.com">Python Tutor Live</a>
		<a id="votr" href="https://votr.uniba.sk/" title="lepsi AIS">Votr</a>
		<a id="moja-uniba" href="https://moja.uniba.sk/">moja.uniba.sk</a>
            </div>

      </section>
    <?php
    
    include('aside.php');
    include('article.php');

    ?>

<?php
include('footer.html');
?>
