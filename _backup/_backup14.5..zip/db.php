<?php

$mysqli = new mysqli('localhost',  'admin', 'admin', 'rozcestnik');
//$mysqli = new mysqli('mysql57.websupport.sk', 'kmsivnvw', 'gcZjL0c2yo', 'kmsivnvw', 3311);
if ($mysqli->connect_errno) {
	echo '<p class="chyba">NEpodarilo sa pripojiť!</p>';
//	echo '<p class="chyba">NEpodarilo sa pripojiť! (' . $mysqli->connect_errno . ' - ' . $mysqli->connect_error . ')</p>';
} else {
	$mysqli->query("SET CHARACTER SET 'utf8'");
}

?>
