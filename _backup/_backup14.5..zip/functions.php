<?php

function head_func(){
	?>
	<!DOCTYPE html>
	<html lang="sk">
	   <head>
	      <meta charset="utf-8">
	      <title>Daniel Grohol</title>
	      <link rel="stylesheet" href="style-full.css" media="all" />
	      <link rel="stylesheet" href="style-mini.css" media="screen and (max-device-width:482px)" />
	      <!-- <script src="script.js"></script> -->
	   </head>
	   <body>

	      <header>
		<a href="index.php"><img src="img/logo.png" alt="logo" id="logo"></a> <br>
	            <a href="index.php" id="site_name">Rozcestník aplikovaného matfyzáka</a>


					 <div id='login'>
						<?php
						if (isset($_POST['email']) && isset($_POST['pass']) && $user = check_user($_POST['email'], $_POST['pass'] )){
							$_SESSION['email'] = $user['email'];
                            $_SESSION['email'] = $user['email'];
                            $_SESSION['user_id'] = $user['user_id'];
						} elseif (isset($_POST['logout_but'])) { // bol odoslany formular s odhlasenim
							session_unset();
							session_destroy();
						}

						if (isset($_SESSION['email'])) {
						?>
						<p>Vitajte v systéme <strong><?php echo $_SESSION['email'];?></strong>.</p>
						<form method="post">
					  	<p>
							 <input type="submit" name="logout_but" id="logout_but" value="Odhlás ma"> <!-- logout_but - odhlasovacie tlacidlo -->
						  </p>
						</form>
						<?php

						}  else {
						?>

						<form method="post">
						 <table>
							<tr>
							 <td><label for="email">Email:</label></td>
							 <td><label for="pass">Heslo:</label></td>
							 <td><a href="register.php">Registrácia</a></td>
							</tr>
							<tr>
							 <td><input type="text" name="email" id="email"></td>
							 <td><input type="password" name="pass" id="pass"></td>
							 <td><input type="submit" name="login_but" id="login_but" value="Prihlás ma"></td>
							</tr>


						 </table>
						 </form>

						<?php
			}
			?>
			<!-- tieto 3 dalsie riadky sa musia vypisat vzdy!-->

		</div>
	</header>
	<?php
	}

// vrati udaje pouzivatela ako asociativne pole, ak existuje pouzivatel $username s heslom $pass, inak vrati FALSE
function check_user($email, $pass){
	global $mysqli;
	if (!$mysqli->connect_errno) {
		$sql = "SELECT * FROM rozcestnik_users WHERE email='$email' AND pass=MD5('$pass')";  // definuj dopyt
//	    "sql = $sql <br/>";
		if (($result = $mysqli->query($sql)) && ($result->num_rows > 0)) {  // vykonaj dopyt
			//echo "Dany uzivatel existuje!"; // dopyt sa podarilo vykonať
			$row = $result->fetch_assoc();
			$result->free();
			return $row;
		} else {
			echo '<p class="chyba">Meno alebo heslo je nespravne!</p>';// dopyt sa NEpodarilo vykonať, resp. používateľ neexistuje!
			return false;
		}
	} else {
		echo '<p class="chyba">Chyba - Nespojil som sa s databazou!</p>';// NEpodarilo sa spojiť s databázovým serverom!
		return false;
	}
}


function nazov_ok ($nazov) {  // osetri vstup aby neobsahoval nebezpecne znaky - strip_tags funkcia; trim - vyhodi medzery
	$nazov = addslashes(strip_tags(trim($nazov)));
	return strlen($nazov) >= 3 && strlen($nazov) <= 100; //meno vstupu musi mat min 3 znaky
}

function pridaj_pouzivatela() {
	global $mysqli;
	if (!$mysqli->connect_errno) {
		$email = $mysqli->real_escape_string($_POST['email']); // real_escape_string - osetri vstup pre SQL databazu
		$pass = $mysqli->real_escape_string($_POST['pass']);
		$name = $mysqli->real_escape_string($_POST['name']);
		$surname = $mysqli->real_escape_string($_POST['surname']);
		//$admin = isset($_POST['admin']) && ($mysqli->real_escape_string($_POST['admin']) == '1') ? 1 : 0;  // nastavenie admina - dorobit neskor!

		$sql = "INSERT rozcestnik_users SET email = '$email', pass = MD5('$pass'),
		 name = '$name', surname = '$surname', admin='0'"; // definuj dopyt
		//admin = '$admin'"; // DOROBIT NESKOR


		if ($result = $mysqli->query($sql)) {  // vykonaj dopyt
			                                   // dopyt sa podarilo vykonať

            $user_id = $mysqli->insert_id; //naposledy vlozeny uzivatel - jeho id

            $sql_user = "CREATE TABLE `rozcestnik`.`user" . $user_id . "` ( `cube_id` VARCHAR(12) NOT NULL , `url` VARCHAR(50) NOT NULL , `name` VARCHAR(20) NOT NULL , `title` VARCHAR(30) NULL , `color` VARCHAR(20) NOT NULL , PRIMARY KEY (`cube_id`)) ENGINE = InnoDB";

            if ($newtable = $mysqli->query($sql_user)) { //ak uspesne vytvorilo tabulku pre usera ($newtable je 1)
                // echo "Tabulka $newtable bola vytvorena." . "\n"; //test ci vytvori tabulku
                $sql_copy = "INSERT INTO user$user_id SELECT * FROM rozcestnik_cubes"; //dopyt - kopia defaultnej tabulky
                if ($copy_ok = $mysqli->query($sql_copy)) {
                  //  echo "Kopia hotova."; //ak sa kopia podarila
                } else  { echo '<p class="chyba">Kopirovanie z defaultnej tabulky zlyhalo. Kontaktujte administratora.</p>'; }

            } else {echo '<p class="chyba">Nepodarilo sa vytvorit tabulku uzivatela!</p>'; }

	                echo '<p>Vitaj nový člen!</p>' . "\n" . '<p>Som rád, že si súčasťou tohto skvelého projektu!</p>' . "\n";
			return true;
	 	} else {
                        // echo $sql;
			// NEpodarilo sa vykonať dopyt!
			echo '<p class="chyba">Nastala chyba pri pridávaní používateľa, kontaktujte prosím administrátora na: dany05@email.cz';

                        //printf("Connect failed: %s\n", $mysqli->connect_errno); // pre vypisanie danej chyby

                        // kontrola, či nenastala duplicita kľúča (číslo chyby 1062) - prihlasovacie meno už existuje
			if ($mysqli->errno == 1062) echo ' (zadané prihlasovacie meno už existuje)';

			echo '.</p>' . "\n";
			return false;
	        }
	} else {
		// NEpodarilo sa spojiť s databázovým serverom alebo vybrať databázu!
		echo '<p class="chyba">NEpodarilo sa spojiť s databázovým serverom!</p>';
		return false;
	}
}	// koniec funkcie

/*
function add_usertable() { //vytvori tabulku pre pouzivatela

    $sql = "CREATE TABLE " . $_"";
}
 */

function print_cubes($src='rozcestnik_cubes' ) { // src - zdroj odkial sa maju printovat kocky - defaultne je to rozcestnik_cubes
    global $mysqli;
    if (!$mysqli->connect_errno) {
        $sql = "SELECT * FROM $src";
        if ($result = $mysqli->query($sql)) { //vykonaj dopyt

            while ($row = $result->fetch_assoc()){
                echo "<a id='" . $row['cube_id'] . "' href='" . $row['url'] . "'>" . $row['name'] ."</a>";
            }
        } else { echo '<p class="chyba">Kocky: Dopyt sa nepodaril ' .  // dopyt sa nepodaril
           // "Chyba: " . $mysqli->error;  //defaultne nezobrazujeme chyby
            ".</p>";
        }
    }

}

function modify_cubes() {

    ?>

    <?php

}

?>
