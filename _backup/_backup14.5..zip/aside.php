<?php

  if (isset($_SESSION['email'])) {
    ?>
    <aside>
      <div id='aside_panel'>
          <form action="" method="post">
              <fieldset>
                <legend>Nová kocka</legend>
                 <table>
                  <tr>
                   <td><label for="url">URL:</label></td>
                   <td><input type="text" name="url" id="url"></td>
                  </tr>
                  <tr>
                   <td><label for="cube_name">názov kocky:</label></td>
                   <td><input type="text" name="cube_name" id="cube_name"></td>
                  </tr>
                  <tr>
                   <td></td>
                   <td><input type="submit" name="add_cube" id="add_cube" value="Pridaj kocku"></td>
                  </tr>
               </table>
              </fieldset>

           </form>
      </div>

    <?php


  global $mysqli;
  if (isset($_POST['add_cube'])) { //ak bol odoslany formular add_cube
    $url = $_POST['url'];
    $cube_name = $_POST['cube_name'];

    $sql = "INSERT INTO rozcestnik.user" . $_SESSION['user_id'] . " SET name='$cube_name', url='$url'";

    if($result = $mysqli->query($sql)) {
      echo "Pridanie bolo úspešné.";
      echo '<script>$window.location.reload();</script>';
    } else {
      echo "Pridanie - dopyt - nebol uspesny. Kontaktujte administratora.";
      //echo  "Cislo chyby:" . $mysqli->errno;
    }
  }

  echo "</aside>";
}
?>
